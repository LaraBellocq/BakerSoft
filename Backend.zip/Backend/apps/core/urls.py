from django.urls import path

urlpatterns = [
    # reservado para /api/v1/health si luego migramos aca
]
